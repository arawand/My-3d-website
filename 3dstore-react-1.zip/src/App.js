// Main React component
import { useState } from "react";
import { ethers } from "ethers";

const products = [
  {
    id: 1,
    name: "3D Model: Sci-fi Gun",
    priceUSD: 25,
    image: "https://via.placeholder.com/200x150?text=Sci-fi+Gun"
  },
  {
    id: 2,
    name: "3D Model: Spaceship",
    priceUSD: 50,
    image: "https://via.placeholder.com/200x150?text=Spaceship"
  }
];

const USDT_ADDRESS = "0x55d398326f99059fF775485246999027B3197955"; // USDT on BSC
const MERCHANT_ADDRESS = "0xYourWalletAddressHere";
const USDT_ABI = ["function transfer(address to, uint amount) public returns (bool)", "function decimals() view returns (uint8)"];

export default function App() {
  const [account, setAccount] = useState(null);
  const [status, setStatus] = useState("");

  async function connectWallet() {
    if (!window.ethereum) return alert("MetaMask not found");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const address = await signer.getAddress();
    setAccount(address);
  }

  async function buy(product) {
    setStatus("Waiting for MetaMask...");
    const provider = new ethers.BrowserProvider(window.ethereum);
    const signer = await provider.getSigner();
    const usdt = new ethers.Contract(USDT_ADDRESS, USDT_ABI, signer);

    const decimals = await usdt.decimals();
    const amount = ethers.parseUnits(product.priceUSD.toString(), decimals);

    try {
      const tx = await usdt.transfer(MERCHANT_ADDRESS, amount);
      await tx.wait();
      setStatus(`Payment successful for ${product.name}!`);
    } catch (err) {
      console.error(err);
      setStatus("Transaction failed or rejected.");
    }
  }

  return (
    <div className="p-6 space-y-4">
      <h1 className="text-2xl font-bold">Buy 3D Objects</h1>
      <button
        onClick={connectWallet}
        className="bg-blue-600 text-white px-4 py-2 rounded"
      >
        {account ? `Connected: ${account.slice(0, 6)}...` : "Connect MetaMask"}
      </button>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
        {products.map((product) => (
          <div key={product.id} className="border p-4 rounded shadow">
            <img src={product.image} alt={product.name} className="mb-2" />
            <h2 className="text-lg font-semibold">{product.name}</h2>
            <p>${product.priceUSD}</p>
            <button
              onClick={() => buy(product)}
              className="mt-2 bg-green-600 text-white px-4 py-1 rounded"
            >
              Buy with MetaMask
            </button>
          </div>
        ))}
      </div>

      {status && <p className="mt-4 text-sm text-gray-700">{status}</p>}
    </div>
  );
}
